<?php
if (isset($_GET["sid"])) {
    $sid = $_GET["sid"];

    require_once("includes/_data.php");

    // إستخراج الرابط المراد الانتقال إليه
    $stmt = $conn->prepare("SELECT slink FROM slider WHERE sid=:sid");
    $stmt->bindParam(":sid", $sid);
    $stmt->execute();
    $record = $stmt->fetch(PDO::FETCH_ASSOC);
    $link = $record["slink"];

    // زيادة عداد الضغطات للرابط المحدد
    if (strlen($link) > 0) {
        $stmt = $conn->prepare("UPDATE slider SET scliks=scliks+1 WHERE sid=:sid");
        $stmt->bindParam(":sid", $sid);
        $stmt->execute();
        header("location:" . $link);
        exit();
    } else {
        header("location:index.php");
    }
} else {
    header("location:index.php");
}
?>














