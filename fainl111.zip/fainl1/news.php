   <?php require("includes/_header.php"); ?>
    
      <div class="h1 text-center p-3">التصاميم</div>
      <div class="row mt-3">
      <?php
// PDO connection (assuming you've already established it)

$stmt = $conn->prepare("SELECT * FROM news WHERE ns='show' ORDER BY nid DESC");
$stmt->execute();

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $title = $row["ntitle"];
    $exert = $row["nexert"];

    if (strlen($title) > 80) {
        $title = substr($title, 0, 80);
        $title = substr($title, 0, strrpos($title, " ")) . " ... ";
    }
    if (strlen($exert) > 180) {
        $exert = substr($exert, 0, 180);
        $exert = substr($exert, 0, strrpos($exert, " ")) . " ... ";
    }

    echo '<div class="card col-lg-3">
        <a href="news-view.php?id=' . $row["nid"] . '"><img src="control/' . $row["nimg"] . '" class="card-img-top border border-bordered" alt="..."/></a>
        <div class="card-body">
            <h5 class="card-title"><a href="news-view.php?id=' . $row["nid"] . '">' . $title . '</a></h5>
            <p class="card-text "><a href="news-view.php?id=' . $row["nid"] . '">' . $exert . '</a></p>
            <a href="news-view.php?id=' . $row["nid"] . '" class="btn  btn-warning-dark w-100">تفاصيل أكثر</a>
        </div>
    </div>';
}
?>

      </div>
    </div>

    <?php require("includes/_footer.php"); ?>