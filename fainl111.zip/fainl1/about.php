   <?php require_once("includes/_header.php"); ?>
       <div class="h1 text-center p-3">من نحن</div>
    

    <?php require_once("includes/_footer.php"); ?>