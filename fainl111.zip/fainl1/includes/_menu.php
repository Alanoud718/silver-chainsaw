<nav class="navbar navbar-expand-lg mt-1 bg-light shadow" style="background-color: DodgerBlue; border-radius: 5px; color: white;"  >
  <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div><a class="nav-link" href="control/index.php"><i class="fa fa-user-circle-o fs-2" aria-hidden="true"></i></a></div>
    <form class="d-flex" action="search.php" method="GET">
          <div><i class="fa fa-search fs-4 text-dark p-2" aria-hidden="true"></i></div>
    <input class="form-control me-2" type="search" name="st" id="st" placeholder="للبحث؟" required="required" maxlength="30" /> &nbsp;&nbsp;
            <input class="btn btn-outline-success" type="submit" value="إبحث" />
        </form>
        <div class="control me-2">
    <button class="btn btn-outline-success" onclick="history.back()">العودة</button>
</div>
    <div class="collapse navbar-collapse " id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 fs-5">
      <?php

try {
    $stmt = $conn->prepare("SELECT cid, cn FROM cats WHERE cs='active'");
    $stmt->execute();

    while ($row = $stmt->fetch()) {
        echo '<div class="control me-2 nav-item">';
        echo '<a class="btn btn-outline-dark"  href="categories.php?cid=' . $row["cid"] . '">&nbsp;&nbsp;&nbsp;&nbsp;' . $row["cn"] . '</a>';
        echo '</div>';
    }
} catch (PDOException $e) {
    echo "خطأ في جلب البيانات من قاعدة البيانات: " . $e->getMessage();
}

?>

                  <li class="nav-item">
          <a class="nav-link text-dark" href="contact.php">&nbsp;&nbsp; 
            <i class="fa fa-youtube fs-2 text-danger" aria-hidden="true"></i>&nbsp; &nbsp; 
            <i class="fa fa-facebook-square fs-2 text-primary" aria-hidden="true"></i>&nbsp; &nbsp; 
                       <i class="fa fa-whatsapp fs-2 text-success" aria-hidden="true"></i>&nbsp; &nbsp; 
                       <i class="fa fa-twitter fs-2 text-primary" aria-hidden="true"></i>
          
          
          </a>
        </li>
      </div>
      </ul>
<div>   
     
    </div>
  </div>
</nav>