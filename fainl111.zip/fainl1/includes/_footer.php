<div class="row">
<div id="footer" class="col-12 text-center h5 mt-5 p-2 hideonprint" style="color: white; text-shadow: 1px 1px 2px black, 0 0 25px rgb(255, 0, 0), 0 0 5px darkblue; font-size: 30px; font-family: Audiowide, sans-serif;   ">
   &quot;  موقع تصميم  &copy; <?php  echo date("Y"); ?> &quot;
   </div>
</div>
</div>


<?php include("includes/_js.php"); ?>
</body>
</html>