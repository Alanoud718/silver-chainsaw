<?php require_once("includes/_data.php"); ?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="" />
    <meta name="keywords" content="طوفان الاقصي" />
    <meta name="author" content="Eng_Abubaker" />
    <title>تصاميم</title>
   <?php include("includes/_css.php"); ?>
</head>

<body class="  text-dark bg-opacity-25 container shadow-lg p-2 mb-4 rounded">

<?php require_once("includes/_menu.php"); ?>
<div class="container bg-light rounded ">

   
    <div class="container">
        <div class="row align-items-center justify-content-center flex-row-reverse">
            <div class="col-4">
                <img class="mt-1 "width="50%" src="imges/add<?php echo rand(1,5);?>.png" alt="' تصاميم'"/>
            </div>
            <div class="col-8 mt-2 text-center">
                 <img width="200px" src="imges/logo.png" alt=""/><br>
                
             
            </div>
        </div>
    </div>


