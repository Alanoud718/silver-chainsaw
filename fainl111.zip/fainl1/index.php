<?php
require_once("includes/_header.php");

// slider start php
$inds = "";
$slides = "";
$active = 'active';
$i = 0;
$sids = "";

$stmt = $conn->prepare("SELECT * FROM slider WHERE ss='active' ORDER BY sid DESC");
$stmt->execute();

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $sids .= $row["sid"] . ",";

    // indecator code
    $inds .= '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="' . $i++ . '" ';
    if (strlen($active) > 0) {
        $inds .= 'class="active" aria-current="true"';
    }
    $inds .= 'aria-label="Slide 1"></button>';

    // slide code 
       if (strlen($row["slink"]) > 0) {
        $slides .= '<div class="carousel-item ' . $active . '">
        <a href="slider-counter.php?sid=' . $row["sid"] . '" target="_blank"><img src="control/' . $row["simg"] . '" class="d-block w-100 simg" alt="' . $row["sname"] . '"/></a>
        <div class="carousel-caption d-none d-md-block">
          <a href="slider-counter.php?sid=' . $row["sid"] . '"><h5>' . $row["stextmain"] . '</h5></a>
          <a href="slider-counter.php?sid=' . $row["sid"] . '"><p>' . $row["stextsub"] . '</p></a>
        </div>
      </div>';
    } else {
        $slides .= '<div class="carousel-item ' . $active . '">
        <img src="control/' . $row["simg"] . '" class="d-block w-100 simg" alt="' . $row["sname"] . '"/>
        <div class="carousel-caption d-none d-md-block">
          <h5>' . $row["stextmain"] . '</h5>
          <p>' . $row["stextsub"] . '</p>
        </div>
      </div>';
    }
    $active = "";
}

// تحديث عداد المشاهدات للسلايدر
$stmt = $conn->prepare("UPDATE slider SET sview=sview+1 WHERE sid IN(:sids)");
$stmt->bindParam(':sids', substr($sids, 0, -1));
$stmt->execute();

//slider end php
?>
   <!-- Slider - start -->
   <div class="row">
   <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
   <?php echo $inds; ?>
  </div>
  <div class="carousel-inner">
  <?php echo $slides; ?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
   <!-- Slider - End -->
      <!-- news Card - start -->
    
      <div class="row mt-3">
         <?php
      $stmt = $conn->prepare("SELECT * FROM news WHERE ns='show' ORDER BY nid DESC LIMIT 8;");
      $stmt->execute();
      
      // 4. احصل على السجلات من الاستعلام
      $rows = $stmt->fetchAll();
      
      // 5. معالجة السجلات
      foreach ($rows as $row) {
      
          $title = $row["ntitle"];
          $exert = $row["nexert"];
      
          if (strlen($title) > 80) {
              $title = substr($title, 0, 80) . "...";
          }
          if (strlen($exert) > 180) {
              $exert = substr($exert, 0, 180) . "...";
          }
            echo '<div class="card col-lg-3">
            <a href="news-view.php?id='.$row["nid"].'"><img src="control/'.$row["nimg"].'" class="card-img-top border border-bordered" alt="..."/></a>
            <div class="card-body">
               <h5  class="card-title"><a style="color: hsl(179, 100%, 30%);" href="news-view.php?id='.$row["nid"].'">'.$title.'</a></h5>
               <p style="text-align: justify;" class="card-text"><a href="news-view.php?id='.$row["nid"].'">'.$exert.'</a></p>
               <a  href="news-view.php?id='.$row["nid"].'" style="background-color:hsl(179, 73%, 92%); color: black; border-radius: 20px" class="btn btn-primary w-100 shadow "> تفاصيل أكثر &nbsp;&nbsp;&nbsp;<i class="fa fa-chevron-circle-down" aria-hidden="true"></i></a>
            </div>
         </div>';
         }
         ?>
      </div>
     <!-- news Card - end -->

    <?php require_once("includes/_footer.php"); ?>




    
