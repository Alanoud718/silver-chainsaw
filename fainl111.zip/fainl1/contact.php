<?php
   session_start();

   require_once("includes/_header.php");

   if($_SERVER["REQUEST_METHOD"]!=="POST")
           {
               $n1=rand(0,99);
               $n2=rand(0,99);
               $res=$n1+$n2;
               $_SESSION["captcha"]=$res;
               $_SESSION["cap"]=$n1."+".$n2."=";
           }
               ?>
           
   <div class="row">
       <div class="col-lg-6 col-sm-12">
       <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7694.7549862359665!2d44.20908918947516!3d15.356028870945785!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1603dbae7c0459cf%3A0xcda0f55ab0108998!2z2YXYpNiz2LPYqSDYp9mE2KvZiNix2Kkg2YTZhNi12K3Yp9mB2Kkg2YjYp9mE2LfYqNin2LnZhyDZiNin2YTZhti02LEgLSDYp9mE2KXYr9in2LHYqSDYp9mE2KrYrNin2LHZitip!5e0!3m2!1sar!2s!4v1644774768762!5m2!1sar!2s" width="100%" height="700" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
       </div>
       <div class="col-lg-6 col-sm-12">
           <h3>إتصل بنا</h3>
           <div class="p-2 text-white bg-dark rounded-3">لا تتردد في الاتصال بنا ومراسلتنا وسيقوم المختصين بالرد عليك في أسرع وقت ممكن إن شاء الله</div>
           <?php

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_COOKIE["gti_send"])) {
            echo "<div class='mt-3 p-2 text-white bg-warning rounded-3'>عذرا لا يمكن إرسال أكثر من رسال، جرب مرة أخرى غدًا</div>";
        } else {
            $sn = $_POST["sn"];
            $sp = $_POST["sp"];
            $se = $_POST["se"];
            $sa = $_POST["sa"];
            $st = $_POST["st"];
            $sm = $_POST["sm"];
            $cx = $_POST["cx"];

            if ($cx == $_SESSION["captcha"]) {
                //server side Validation
                $errMsg = "<ul>";
                if (strlen($sn) == 0) {
                    $errMsg .= "<li>الرجاء إضافة إسم المرسل</li>";
                }
                if (strlen($sp) == 0 && strlen($se) == 0) {
                    $errMsg .= "<li>الرجاء إضافة وسيلة التواصل معكم</li>";
                }
                if (strlen($st) == 0) {
                    $errMsg .= "<li>الرجاء إضافة عنوان الرسالة</li>";
                }
                if (strlen($sm) == 0) {
                    $errMsg .= "<li>الرجاء إضافة نص الرسالة</li>";
                }
                $q="SELECT email from userss WHERE email='$se'";
                $stm=$conn->prepare($q);
                $stm->execute();
                $data=$stm->fetch();
                if(!$data)
                {
                    $errMsg .= "<li> الايميل خاطاء او لا يوجد لديك حساب</li>";

                }


                $errMsg .= "</ul>";
                if (strlen($errMsg) > 9) {
                    echo "<div class='mt-3 p-2 text-white bg-danger rounded-3'>" . $errMsg . "</div>";
                } else {
                    $stmt = $conn->prepare("INSERT INTO msg (msubject, mbody, mname, mtelephone, memail, mto, ms) VALUES (:st, :sm, :sn, :sp, :se, :sa, 'unread')");
                    $stmt->bindParam(":st", $st);
                    $stmt->bindParam(":sm", $sm);
                    $stmt->bindParam(":sn", $sn);
                    $stmt->bindParam(":sp", $sp);
                    $stmt->bindParam(":se", $se);
                    $stmt->bindParam(":sa", $sa);
                    $stmt->execute();
                    echo "<div class='mt-3 p-2 text-white bg-success rounded-3'>تم إرسال رسالتك بنجاح</div>";
                    setcookie("gti_send", "true", time()+86400);
                }
            } else {
                echo "<div class='mt-3 p-2 text-white bg-danger rounded-3'>لقد فشلت في اختبار الإنسانية</div>";
            }
        }
    }
} catch (PDOException $e) {
    echo "خطأ في معالجة الرسالة: " . $e->getMessage();
}

?>

           <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="POST">
            <div class="mb-3 ">
                <label for="sn" class="form-label">إسم المرسل</label>
                <input type="text" class="form-control" id="sn" name="sn" placeholder="الرحاء كتابة الاسم كاملا"/>
            </div>
            <div class="mb-3">
                <label for="sp" class="form-label">جوال المرسل</label>
                <input type="text" class="form-control" id="sp" name="sp" placeholder="الرجاء كتابة الهاتف"/>
            </div>
            <div class="mb-3">
                <label for="se" class="form-label">البريد الإلكتروني</label>
                <input type="email" class="form-control" id="se" name="se" placeholder="الرحاء كتابة الإيميل الخاص بك"/>
            </div>
            <div class="mb-3">
                <label for="sa" class="form-label">الإدارة المرسل إليه</label>
                <select class="form-select" id="sa" name="sa">
                    <option>إدارة الإعلانات</option>
                    <option>إدارة التحرير</option>
                    <option>إدارة الشكاوي</option>
                    <option>إدارة حقوق الملكية الفكرية</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="st" class="form-label">عنوان الرسالة</label>
                <input type="text" class="form-control" id="st" name="st" placeholder="الرحاء كتابة الاسم كاملا"/>
            </div>
            <div class="mb-3">
                <label for="sm" class="form-label">الرسالة</label>
                <textarea class="form-control" id="my-text" name="sm" maxlength="100">  </textarea>
                <span id="my-span"></span>
            </div>
            <div class="mb-3">
            <label for="cx" class="form-label"><?php echo $_SESSION["cap"]; ?></label>
                <input type="number" class="form-control" id="cx" name="cx" />
            </div>

            <div class="mb-3 text-start">
            <button id="my-submit" type="submit" class="btn btn-dark">إرسال الرسالة</button>
            </div>
           </form>
       </div>
   </div>  
   

<script>

   var myText 	= document.getElementById("my-text"),
		mySpan 	= document.getElementById("my-span"),
    maxLength = mySpan.textContent | 100,
    minLength = 20;
    
myText.oninput = function(){
	'use strict';
	var inSpan = maxLength - myText.value.length;
  mySpan.textContent = inSpan;

  if(inSpan < minLength){
  	mySpan.style.color = "red";
  }else{
  	mySpan.style.color = "#000";
  }
};
mySpan.textContent = maxLength;

</script>


    <?php require_once("includes/_footer.php"); ?>