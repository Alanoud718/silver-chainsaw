-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 28 يناير 2024 الساعة 23:15
-- إصدار الخادم: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `disigins`
--

-- --------------------------------------------------------

--
-- بنية الجدول `cats`
--

CREATE TABLE `cats` (
  `cid` int(11) NOT NULL,
  `cn` varchar(100) NOT NULL COMMENT 'الاسم',
  `cs` set('active','inactive') NOT NULL DEFAULT 'active' COMMENT 'الحالة'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `cats`
--

INSERT INTO `cats` (`cid`, `cn`, `cs`) VALUES
(10, 'تصميم فوتوشب', 'active'),
(11, 'تصميم كروت', 'active');

-- --------------------------------------------------------

--
-- بنية الجدول `log`
--

CREATE TABLE `log` (
  `lid` int(11) NOT NULL,
  `lin` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'تاريخ الإضافة',
  `lt` varchar(150) NOT NULL COMMENT 'نص العملية',
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `msg`
--

CREATE TABLE `msg` (
  `mid` int(11) NOT NULL,
  `msubject` varchar(200) NOT NULL,
  `mbody` text NOT NULL,
  `mname` varchar(50) NOT NULL,
  `mtelephone` varchar(50) DEFAULT NULL,
  `memail` varchar(50) DEFAULT NULL,
  `min` datetime NOT NULL DEFAULT current_timestamp(),
  `ms` set('read','unread') NOT NULL,
  `mto` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `msg`
--

INSERT INTO `msg` (`mid`, `msubject`, `mbody`, `mname`, `mtelephone`, `memail`, `min`, `ms`, `mto`) VALUES
(8, 'wed', '  wed', 'عبدالله عبدالعزيز', '23423423', 'eng.fahd99@gmail.com', '2024-01-28 00:24:36', 'unread', 'إدارة التحرير');

-- --------------------------------------------------------

--
-- بنية الجدول `news`
--

CREATE TABLE `news` (
  `nid` int(11) NOT NULL,
  `npid` varchar(100) NOT NULL COMMENT 'الإسم الظاهر',
  `uid` int(11) NOT NULL,
  `nin` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'تأريخ الإضافة',
  `ns` set('show','hide') NOT NULL DEFAULT 'show' COMMENT 'الحالة',
  `cid` int(11) NOT NULL COMMENT 'الربط مع الكاتورجي',
  `ntitle` varchar(100) NOT NULL COMMENT 'عنوان الخبر',
  `nexert` varchar(200) NOT NULL COMMENT 'ملخص',
  `ntext` text NOT NULL COMMENT 'نص الخبر',
  `nsource` varchar(50) NOT NULL COMMENT 'مصدر الخبر',
  `nauthor` varchar(50) NOT NULL COMMENT 'الكاتب',
  `nimg` varchar(100) NOT NULL,
  `ner` int(11) NOT NULL DEFAULT 0 COMMENT 'عداد ',
  `nsr` int(11) NOT NULL DEFAULT 0 COMMENT 'عداد',
  `nd` varchar(3) NOT NULL DEFAULT 'no' COMMENT 'الحذف'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `slider`
--

CREATE TABLE `slider` (
  `sid` int(11) NOT NULL,
  `sname` varchar(50) NOT NULL COMMENT 'إسم داخلي للتمييز',
  `simg` varchar(100) NOT NULL COMMENT 'رابط الصورة',
  `slink` varchar(100) NOT NULL COMMENT 'الرابط اللي يروح إليه',
  `sview` int(11) NOT NULL COMMENT 'كم مرة مشاهدة للصورة',
  `scliks` int(11) NOT NULL COMMENT 'كم مرة نقر',
  `ss` set('active','inactive') NOT NULL COMMENT 'حالة السلايدر',
  `stextmain` varchar(50) DEFAULT NULL,
  `stextsub` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `udn` varchar(50) NOT NULL COMMENT 'الاسم الظاهر',
  `un` varchar(50) NOT NULL COMMENT 'إسم المستخدم',
  `up` mediumtext NOT NULL COMMENT 'تلفون المستخدم',
  `ut` set('admin','editor','author','publisher') NOT NULL COMMENT 'نوع المستخدم',
  `us` set('active','inactive') NOT NULL COMMENT 'حالة المستخدم',
  `ulin` datetime DEFAULT NULL COMMENT 'أخر دخول',
  `uimg` varchar(255) NOT NULL COMMENT 'صورة المستخدم'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`uid`, `udn`, `un`, `up`, `ut`, `us`, `ulin`, `uimg`) VALUES
(33, 'عبدالله', '777776666', '$2y$10$88/wj.Imm5gRxyJDeBOZxOdbcf6w3.FGBN9l3QiFfTAyqpDbLjqkO', 'admin', 'active', '2024-01-29 01:12:15', 'uploads/user-20240127-1706383217.jpg'),
(36, 'شيماء', '777777777', '$2y$10$OHzxjG7iHfxnSKGP2GXZbONNTaYYba1L913JN35xzKkhLO6MdY4Ee', 'admin', 'active', '2024-01-29 01:12:58', 'uploads/user-20240128-1706479960.jpg');

-- --------------------------------------------------------

--
-- بنية الجدول `userss`
--

CREATE TABLE `userss` (
  `uid` int(11) NOT NULL COMMENT 'id',
  `names` varchar(50) NOT NULL COMMENT 'إسم المستخدم',
  `email` varchar(50) NOT NULL COMMENT 'البريد الالكتروني',
  `passwords` mediumtext NOT NULL COMMENT 'password',
  `phone` varchar(50) NOT NULL COMMENT 'تلفون المستخدم',
  `s` set('active','inactive') NOT NULL COMMENT 'حالة المستخدم',
  `lin` datetime DEFAULT NULL COMMENT 'أخر دخول',
  `uimg` varchar(255) NOT NULL COMMENT 'صورة المستخدم'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cats`
--
ALTER TABLE `cats`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`lid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `msg`
--
ALTER TABLE `msg`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`nid`),
  ADD KEY `cid` (`cid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `userss`
--
ALTER TABLE `userss`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cats`
--
ALTER TABLE `cats`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `lid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `msg`
--
ALTER TABLE `msg`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `nid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `userss`
--
ALTER TABLE `userss`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id', AUTO_INCREMENT=26;

--
-- قيود الجداول المُلقاة.
--

--
-- قيود الجداول `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `log_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`);

--
-- قيود الجداول `news`
--
ALTER TABLE `news`
  ADD CONSTRAINT `news_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `cats` (`cid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
