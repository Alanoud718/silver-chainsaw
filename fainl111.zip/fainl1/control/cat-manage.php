<?php require_once("includes/_header.php"); ?>
    
    <div class="h1  p-3 test-end">أقسام التصاميم <a href='cat-add.php' class='btn btn-outline-warning float-start'>إضافة قسم</a></div>
    <?php

// التعطيل والتفعيل
if (isset($_GET["cid"]) && isset($_GET["a"])) {
    $cid = $_GET["cid"];
    $a = $_GET["a"];

    // حدد الحالة الصحيحة بناءً على قيمة `$a`
    if ($a == "e") {
        $cs = "active";
    } else {
        $cs = "inactive";
    }

    $stmt = $conn->prepare("UPDATE cats SET cs=:cs WHERE cid=:cid");
    $stmt->bindParam(":cs", $cs);
    $stmt->bindParam(":cid", $cid);
    $stmt->execute();

    // عرض رسالة النجاح المناسبة
    if ($a == "e") {
        echo "<div class='alert alert-success'>تم التفعيل بنجاح</div>";
    } else {
        echo "<div class='alert alert-success'>تم التعطيل بنجاح</div>";
    }
}

?>

<div class="table-responsive">
    <table class="table table-hover table-responsive table-border">
        <tr>
            <th>الرقم</th>
            <th>الاسم</th>
            <th>الحالة</th>
            <th>&nbsp;</th>
        </tr>
        <?php
        $stmt = $conn->prepare("SELECT * FROM cats ORDER BY cid DESC");
        $stmt->execute();

        while ($record = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $s = $record["cs"] == "active" ? "مفعل" : "معطل";

            echo "<tr>
                <td>" . $record["cid"] . "</td>
                <td>" . $record["cn"] . "</td>
                <td>" . $s . "</td>
                <td>
                    <a href='cat-edit.php?cid=" . $record["cid"] . "' class='btn btn-primary'>تعديل</a> &nbsp;
                    <a href='cat-manage.php?cid=" . $record["cid"] . "&a=" . ($record["cs"] == "active" ? "d" : "e") . "' class='btn " . ($record["cs"] == "active" ? "btn-warning" : "btn-success") . "'>" . ($record["cs"] == "active" ? "تعطيل" : "تفعيل") . "</a>
                </td>
            </tr>";
        }
        ?>
 
    </tr>
        </table>
        </div>

  <?php require_once("includes/_footer.php"); ?>