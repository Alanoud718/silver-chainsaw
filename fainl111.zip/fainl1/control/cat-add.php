<?php require_once("includes/_header.php");?>
               
    <div class="h1  p-3 test-end"> إضافة قسم <a href='cat-manage.php' class='btn btn-outline-warning float-start'>إدارة الأقسام</a></div>
    <?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cn = $_POST["cn"];

    $stmt = $conn->prepare("INSERT INTO cats (cn) VALUES (:cn)");
    $stmt->bindParam(":cn", $cn);
    $stmt->execute();
}
?>

        
         
    <form action="cat-add.php" method="post">
    <div>
        <label for="cn">إسم القسم</label>
        <input type="text" id="cn" name="cn" placeholder="التصنيف" required="required" maxlength="100"/>
        <input onclick="neww();" type="submit" value="حفظ" class="btn btn-dark">
     
    </div>
   </form>
   
   <script>
        function neww(){
            Swal.fire({
  title: 'تم إضافة القسم بنجاح!',
  text: 'هل تريد حفظ قسم جديد',
  icon: 'success',
  confirmButtonText: 'جيد جدًا '
})
        }
    </script>


<script src="jquery-3.6.0.min.js"></script>
                <script src="sweetalert2.all.min.js"></script>

  <?php require_once("includes/_footer.php"); ?>