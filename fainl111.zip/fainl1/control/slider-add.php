<?php
 require_once("includes/_header.php");
 if($_SERVER["REQUEST_METHOD"]=="POST")
        {
        if($_FILES["simg"]["size"]>0)
        {
            if($_FILES["simg"]["type"]=="image/jpeg")
            {
                $filename="uploads/"."slider-".date("Ymd")."-".time().".jpg";
                move_uploaded_file($_FILES["simg"]["tmp_name"],$filename);

                $sn=$_POST["sn"];
                $sl=$_POST["sl"];
                $smt=$_POST["smt"];
                $sst=$_POST["sst"];

                $con->query("INSERT INTO slider(sname,simg,slink,sview,scliks,ss,stextmain,stextsub) VALUES ('$sn','$filename','$sl','0','0','active','$smt','$sst');");

                echo "<div class='alert alert-success mt-3 mb-3'>تم إضافة السلايدر بنجاح</div>";
            }
            else
            {
                echo "Invalid File type";
            }
        }
        else
        {
            echo "Error,No file";
        }
        }
 ?>
    <div class="h1  p-3 text-end"> إضافة سليدر <a href='slider-manage.php' class='btn btn-outline-warning float-start'>إدارة السليدرات</a></div>
    <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">
        <div class="mt-3">
            <label class="form-label" for="sn">الإسم</label>
            <input class="form-control" type="text" id="sn" name="sn"  required="required" maxlength="100"/>
        </div>
        <div class="mt-3">
            <label class="form-label" for="sl">الرابط</label>
            <input class="form-control" type="url" id="sl" name="sl"  maxlength="100"/>
        </div>
        <div class="mt-3">
            <label class="form-label" for="smt">العنوان الرئيسي</label>
            <input class="form-control" type="text" id="smt" name="smt"  required="required" maxlength="50"/>
        </div>
        <div class="mt-3">
            <label class="form-label" for="sst">العنوان الفرعي</label>
            <input class="form-control" type="text" id="sst" name="sst"  maxlength="100"/>
        </div>
        <div class="mt-3">
            <label class="form-label" for="simg">الصورة</label>
            <input class="form-control" type="file" id="simg" name="simg" required="required" maxlength="100"/>
        </div>
        <div class="mt-3">
        <input type="submit" value="حفظ" class="btn btn-primary">
        </div>
   </form>

  <?php require_once("includes/_footer.php"); ?>