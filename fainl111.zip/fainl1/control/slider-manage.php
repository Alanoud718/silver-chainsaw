<?php require_once("includes/_header.php"); ?>
<?php

if (isset($_GET["action"]) && isset($_GET["id"])) {

    $sid = $_GET["id"];

    if ($_GET["action"] == "enable") {

        $stmt = $conn->prepare("UPDATE slider SET ss='active' WHERE sid=:sid");
        $stmt->bindParam(":sid", $sid);
        $stmt->execute();

        $msg = "تم التفعيل بنجاح";
    } else if ($_GET["action"] == "disable") {

        $stmt = $conn->prepare("UPDATE slider SET ss='inactive' WHERE sid=:sid");
        $stmt->bindParam(":sid", $sid);
        $stmt->execute();

        $msg = "تم التعطيل بنجاح";
    }
}

?>

<div class="h1  p-3 text-end">إدارة السلايدر <a href='slider-add.php' class='btn btn-outline-warning float-start'>إضافة السلايدر</a></div>
    <div class="row">
        <div class="col-12">
        <div class="table-responsive">
        <?php
        $msg="";
        if(strlen($msg)>0)
        {
        echo "<div class='m-3 p-3 alert alert-success'>".$msg."</div>";
        }
        ?>
            <table class="table table-bordered table-hover table-striped">
                <tr>
                    <th>الرقم</th>
                    <th>الاسم</th>
                    <th>الزيارات</th>
                    <th>الضغطات</th>
                    <th>الحالة</th>
                    <th>الصورة</th>
                    <th>&nbsp;</th>
                </tr>
                <?php

try {
    $stmt = $conn->prepare("SELECT * FROM slider ORDER BY sid DESC");
    $stmt->execute();

    while ($row = $stmt->fetch()) {
        echo "<tr>";
        echo "<td>" . $row["sid"] . "</td>";
        echo "<td>" . $row["sname"] . "</td>";
        echo "<td>" . $row["sview"] . "</td>";
        echo "<td>" . $row["scliks"] . "</td>";
        echo "<td>" . ($row["ss"] == "active" ? "مفعل" : "معطل") . "</td>";
        echo "<td><img src='" . $row["simg"] . "' alt='' height='60px'/></td>";
        echo "<td><a href='slider-manage.php?action=enable&id=" . $row["sid"] . "' class='btn btn-primary'>تفعيل</a>&nbsp;<a href='slider-manage.php?action=disable&id=" . $row["sid"] . "' class='btn btn-danger'>تعطيل</a></td>";
        echo "</tr>";
    }
} catch (PDOException $e) {
    echo "خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage();
}

?>

            </table>
        </div>
    </div>
</div>


<?php require_once("includes/_footer.php"); ?>