<?php
require_once("includes/_header.php");

if (isset($_GET["cid"])) {
    $cid = $_GET["cid"];

    $stmt = $conn->prepare("SELECT cn FROM cats WHERE cid=:cid");
    $stmt->bindParam(":cid", $cid);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $cn = $row["cn"];
} else {
    header("location:cat-manage.php");
    exit();
}
?>

<div class="h1  p-3 test-end"> تعديل بيانات قسم <a href="cat-manage.php" class="btn btn-outline-warning float-start">إدارة الأقسام</a>&nbsp;<a href="cat-add.php" class="btn btn-outline-warning float-start">إضافة قسم</a></div>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cn = $_POST["cn"];
    $cid = $_POST["cid"];

    $stmt = $conn->prepare("UPDATE cats SET cn=:cn WHERE cid=:cid");
    $stmt->bindParam(":cn", $cn);
    $stmt->bindParam(":cid", $cid);
    $stmt->execute();

    echo "<div class='alert alert-success'>تم تعديل القسم بنجاح</div>";
}
?>

    <form action="cat-edit.php?cid=<?php echo $cid; ?>" method="post">
    <div>
        <label for="cn">الرقم</label>
        <input type="text" id="cid" name="cid"  readonly="true" value="<?php echo $cid; ?>"/>

        <label for="cn">إسم القسم</label>
        <input type="text" id="cn" name="cn" placeholder="التصنيف" required="required" maxlength="100" value="<?php echo $cn; ?>"/>
        <input type="submit" value="حفظ" class="btn btn-primary">
    </div>
   </form>

  <?php require_once("includes/_footer.php"); ?>