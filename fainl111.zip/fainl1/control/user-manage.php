<?php

require_once "includes/_header.php";

//action
if (isset($_GET["action"]) && isset($_GET["id"])) {

    $uid = $_GET["id"];
    $action = $_GET["action"];

    switch ($action) { 
        case "enable":
            try {
                $stmt = $conn->prepare("UPDATE users SET us='active' WHERE uid=:uid");
                $stmt->bindParam(":uid", $uid);
                $stmt->execute();

                $msg = "تم  تفعيل الحساب بنجاح";
            } catch (PDOException $e) {
                $msg = "حدث خطأ في تفعيل الحساب: " . $e->getMessage();
            }
            break;
        case "disable":
            try {
                $stmt = $conn->prepare("UPDATE users SET us='inactive' WHERE uid=:uid");
                $stmt->bindParam(":uid", $uid);
                $stmt->execute();

                $msg = "تم تعطيل الحساب بنجاح";
            } catch (PDOException $e) {
                $msg = "حدث خطأ في تعطيل الحساب: " . $e->getMessage();
            }
            break;
    }
}

?>

<div class="row">
    <div class="col-12">
        <div class="h3">اضافة مستخدم<a href='user-add.php' class='btn btn-outline-warning float-start'>إضافة مستخدم</a></div>
        <?php
        if(isset($msg) && strlen($msg)>0)
        {
        echo "<div class='alert alert-success mt-5 mb-5 p-3'>$msg</div>";
        }
        ?>
        <table class='table table-striped table-bordered table-hover'>
            <tr>
                <th>الرقم</th>
                <th>الاسم</th>
                <th>الهاتف</th>
                <th>حالة الحساب</th>
                <th>نوع الحساب</th>
                <th>أخر دخول</th>
                <th>صورة</th>
                <th>&nbsp;</th>
            </tr>
            <?php

try {
    $stmt = $conn->prepare("SELECT * FROM users ORDER BY uid DESC");
    $stmt->execute();

    while ($row = $stmt->fetch()) {
        echo "<tr>";
        echo "<td>" . $row["uid"] . "</td>";
        echo "<td>" . $row["udn"] . "</td>";
        echo "<td>" . $row["un"] . "</td>";
        echo "<td>" . $row["us"] . "</td>";

        echo "<td>" . ($row["ut"] == "admin" ? "مدير" : ($row["ut"] == "editor" ? "محرر" : ($row["ut"] == "author" ? "ناشر" : "كاتب"))) . "</td>";

        echo "<td>" . $row["ulin"] . "</td>";
        echo "<td><img src='" . $row["uimg"] . "' alt='' height='60px'/></td>";
        echo "<td>";
        echo "<a class='btn btn-primary' href='user-manage.php?action=enable&id=" . $row["uid"] . "'>تفعيل</a>";
        echo "<a class='btn btn-danger' href='user-manage.php?action=disable&id=" . $row["uid"] . "'>تعطيل</a>";
        echo "</td>";
        echo "</tr>";
    }
} catch (PDOException $e) {
    echo "خطأ في جلب البيانات من قاعدة البيانات: " . $e->getMessage();
}
?>


        </table>

    </div>
</div>
