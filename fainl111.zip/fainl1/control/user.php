<?php
require("includes/_data.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if ($_FILES["uimg"]["size"] > 0) {

        if ($_FILES["uimg"]["type"] == "image/jpeg") {

            $filename = "uploads/" . "user-" . date("Ymd") . "-" . time() . ".jpg";
            move_uploaded_file($_FILES["uimg"]["tmp_name"], $filename);

            $names = $_POST["names"];
            $email = $_POST["email"];
            $passwords = $_POST["passwords"];
            $phone = $_POST["phone"];
            $hashed_password = password_hash($_POST['passwords'], PASSWORD_BCRYPT);

            try {
                $stmt = $conn->prepare("INSERT INTO userss(names, email,passwords , phone, s, uimg) VALUES (:names, :email, :passwords, :phone, 'active', :filename)");
                $stmt->bindParam(":names", $names);
                $stmt->bindParam(":email", $email);
                $stmt->bindParam(":passwords", $hashed_password);
                $stmt->bindParam(":phone", $phone);
                $stmt->bindParam(":filename", $filename);
                $stmt->execute();
                header("location:../index.php");    
                    } catch (PDOException $e) {
                echo "خطأ في إضافة المستخدم: " . $e->getMessage();
            }
        } else {
            echo "Invalid File type";
        }
    } else {
        echo "Error, No file";
    }
}

?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="" />
    <meta name="keywords" content="fars travel" />
    <meta name="author" content="Abubaker" />
    <title>fars travel</title>
   <?php require_once("includes/_css.php"); ?>
   <style>
    body{
       
    }
    .wrap{
        background-color: white;
        border: 2px solid black;
        margin: 10vh auto;
        width: 400px;
        padding: 20px;
        border-radius: 30px;
    }
    .wrap .h4{
        border-bottom: 2px solid #000;
        padding-bottom: 10px;
        margin-bottom: 10px;
    }
</style>
</head>
<body>
    <div class="wrap">
<div class="container">
    <div class="row">
        <div class="col-12">
        <div class="control me-2">
    <button class="btn btn-outline-warning" onclick="history.back()">العودة</button>
</div>
            <div class="h4 text-center">انشاء حساب</div>
        </div>
<div class="col-12">
    <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST" enctype="multipart/form-data">
        <div>
            <label for="name" class="form-label">الاسم</label>
            <input type type="text" class="form-control form-select-lg " id="name" name="names" placeholder="name" required="required" maxlength="50" />
        </div>
        <div>
            <label for="email" class="form-label">عنوان البريد الالكتروني</label>
            <input type type="email"  class="form-control" id="email" name="email" placeholder="email" required="required" maxlength="50" />
        </div>
        <div>
            <label for="password" class="form-label">كلمة المرور</label>
            <input type type="password"  class="form-control" id="password" name="passwords" placeholder="password" required="required" maxlength="9" />
        </div>
        <div>
            <label for="tel" class="form-label">رقم الهاتف</label>
            <input type type="phone" class="form-control" id="tel" name="phone" placeholder="telephone" required="required" maxlength="13" />
        </div>
        
            <div>
            <label class="form-label" for="uimg">الصورة</label>
            <input class="form-control" type="file" id="uimg" name="uimg" required="required" maxlength="255"/>
            </div>
            <div class="mt-3">
        <button class="btn btn-outline-warning w-100" type="submit">انشاء</button>
        </div>
    </form>

</div>
</div>
    </div>
<?php require_once("includes/_js.php"); ?>
</body>
</html>