<?php
     require_once("includes/_data.php");
     session_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>1
    <title>Log in</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="" />
    <meta name="keywords" content="fars travel" />
    <meta name="author" content="Abubaker" />
    <title>fars travel</title>
   <?php require_once("includes/_css.php"); ?>
   <style>
    body{
       
    }
    .wrap{
        background-color: white;
        border: 2px solid black;
        margin: 10vh auto;
        width: 400px;
        padding: 20px;
        border-radius: 30px;
    }
    .wrap .h4{
        border-bottom: 2px solid #000;
        padding-bottom: 10px;
        margin-bottom: 10px;
    }
</style>

</head>
<body>
    <div class="wrap">
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="h4 text-center">تسجيل الدخول</div>
        </div>
        <?php
if($_SERVER["REQUEST_METHOD"]=="POST")
{  
    $phone=$_POST["phone"];
    $passwords=$_POST["passwords"];
    $stmt = $conn->prepare("SELECT * FROM userss WHERE phone=?;");
                $stmt->bindParam(1,$phone);
                $stmt->execute();
                    if($user = $stmt->fetch())
                    {
                        if (password_verify($passwords, $user["passwords"]))
                        {
                                if($user["s"]=="active")
                                {
                                    // تحديد أخر عملية الدخول للنظام:
                                    $conn->query("UPDATE userss SET lin=NOW() WHERE phone=$phone;");
        
        
                                // زراعة بيانات المستخدمين في جلسة
                                    $_SESSION["phone"] = $user["names"];
                                    $_SESSION["uid"] = $user["uid"];
                                    header("location:profils.php");
        
                                }
                                else
                                {
                                    echo "<div class='alert alert-danger' >عفوا حسابك معطل من قبل الإدارة</div>";                 
                                }
                        }
                        else
                        {
                        echo "<div class='alert alert-danger' >عفوا كلمة السر المدخلة غير صحيحة</div>";     
                        }
                    }
   
         else
         { 
            $stmt = $conn->prepare("SELECT * FROM users WHERE un=?;");
            $stmt->bindParam(1,$phone);
            $stmt->execute();
                if($user = $stmt->fetch())
                {
                    if (password_verify($passwords, $user["up"]))
                    {
                            if($user["us"]=="active")
                            {
                                // تحديد أخر عملية الدخول للنظام:
                                $conn->query("UPDATE users SET ulin=NOW() WHERE un=$phone;");
        
        
                            // زراعة بيانات المستخدمين في جلسة
                                $_SESSION["un"] = $user["udn"];
                                $_SESSION["ut"] = $user["ut"];
                                $_SESSION["uid"] = $user["uid"];
                                header("location:index.php");
        
                            }
                            else
                            {
                                echo "<div class='alert alert-danger' >عفوا حسابك معطل من قبل الإدارة</div>";                 
                            }
                    }
                    else
                    {
                    echo "<div class='alert alert-danger' >عفوا كلمة السر المدخلة غير صحيحة</div>";     
                    }
                }
        
                
                    else
                    {
                       echo "<div class='alert alert-danger' >عفوا البيانات المدخلة غير صحيحة</div>";
                    }
              }   
}

    ?> 

<div class="col-12">
    <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
        <div>
            <label for="ut" class="form-label">رقم الهاتف</label>
            <input type type="tel" maxlength="9" class="form-control" id="ut" name="phone" placeholder="رقم الجوال" required="required"  />
        </div>
        <div class="mb-3" >
            <label for="up" class="form-label">كلمة المرور</label>
            <input type="password"  class="form-control" id="up" name="passwords" placeholder="كلمة السر" required="required"  />
        </div>
        <button class="btn btn-outline-dark w-100" type="submit">تسجيل الدخول</button>
    </form>
</div>
<div class="text-center mt-3">
    <a class="btn btn-outline-warning" href="user.php">إنشاء حساب</a>
</div>
<div>
    <a class="nav-link text-center " href="../index.php">رجوع إلى الموقع<i class="fa fa-sign-out" aria-hidden="true"></i></a>
</div>
</div>

    </div>

<?php require_once("includes/_js.php"); ?>
</body>
</html>