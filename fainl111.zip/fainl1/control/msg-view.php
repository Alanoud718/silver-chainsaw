<?php require_once("includes/_header.php"); ?>
<style>
    @media screen {
        .userwhoprint{
            display: none;            
        }
    }
    @media print {
           .hideonprint{
        display: none;
    }
}
</style>    
    <div class="h1  p-3 test-end">تفاصيل الرسالة</div>
    <div class="row">
        <div class="col-12">
        <?php

try {

    if (!isset($_GET["mid"])) {
        throw new Exception("لم يتم تحديد رقم الرسالة");
    }

    // تغيير حالة الرسالة
    $mid = $_GET["mid"];
    $stmt = $conn->prepare("UPDATE msg SET ms='read' WHERE mid=:mid");
    $stmt->bindParam(":mid", $mid);
    $stmt->execute();

    // إظهار تفاصيل الرسالة
    $stmt = $conn->prepare("SELECT * FROM msg WHERE mid=:mid");
    $stmt->bindParam(":mid", $mid);
    $stmt->execute();

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

        // عرض تفاصيل الرسالة
        echo "<div class='message-details'>";
        echo "<div class='field'><label>التاريخ:</label> <input class='form-control' type='text' readonly value='" . $row["min"] . "' /></div>";
        echo "<div class='field'><label>الاسم:</label> <input class='form-control' type='text' readonly value='" . $row["mname"] . "' /></div>";
        echo "<div class='field'><label>الهاتف:</label> <input class='form-control' type='text' readonly value='" . $row["mtelephone"] . "' /></div>";
        echo "<div class='field'><label>البريد:</label> <input class='form-control' type='text' readonly value='" . $row["memail"] . "' /></div>";
        echo "<div class='field'><label>الإدارة:</label> <input class='form-control' type='text' readonly value='" . $row["mto"] . "' /></div>";
        echo "<div class='field'><label>العنوان:</label> <input class='form-control' type='text' readonly value='" . $row["msubject"] . "' /></div>";
        echo "<div class='field'><label>الرسالة:</label> <textarea class='form-control' readonly>" . $row["mbody"] . "</textarea></div>";
        echo "</div>";
    } else {
        echo "لم يتم العثور على الرسالة";
    }
} catch (Exception $e) {
    echo "خطأ في معالجة الرسالة: " . $e->getMessage();
}

?>


    <div class="userwhoprint">
        تم طباعة التقرير من قبل: THenoon
    </div>
    <div class="text-start">
        <button class="btn btn-outline-warning mt-3 hideonprint" onClick="window.print();">طباعة</button>
    </div>
        </div>
    </div>  
  <?php require_once("includes/_footer.php"); ?>