<?php
require_once "includes/_header.php";

//action
if(isset($_GET["action"]) && isset($_GET["id"]))
{
    $uid = $_GET["id"];
    $action = $_GET["action"];
    switch($action)
    {
        case "enable":
            // تعديل الاستعلام لربطه بـ PDO
            $stmt = $conn->prepare("UPDATE news SET ns='show' WHERE nid=:uid");
            $stmt->bindParam(":uid", $uid);
            $stmt->execute();
            $msg = "تم  إظهار التصميم بنجاح";
            break;
        case "disable":
            // تعديل الاستعلام لربطه بـ PDO
            $stmt = $conn->prepare("UPDATE news SET ns='hide' WHERE nid=:uid");
            $stmt->bindParam(":uid", $uid);
            $stmt->execute();
            $msg = "تم إخفاء التصميم بنجاح";
            break;
    }
}

?>

<div class="row">
    <div class="col-12">
        <div class="h3">إدارة التصميم<a href='news-add.php' class='btn btn-outline-warning float-start'>إضافة خبر</a></div>
        <?php
        $msg="";
        if(strlen($msg)>0)
        {
        echo "<div class='alert alert-success mt-5 mb-5 p-3'>$msg</div>";
        }
        ?>
        <table class='table table-striped table-bordered table-hover'>
            <tr>
                <th>الرقم</th>
                <th>العنوان</th>
                <th>القسم</th>
                <th>حالة التصميم</th>
                <th>تاريخ الإضافة</th>
                <th>عدد القراءات</th>
                <th>&nbsp;</th>
            </tr>
            <?php

try {
    $stmt = $conn->prepare("SELECT * FROM news a, cats c WHERE c.cid=a.cid");
    $stmt->execute();

    while ($row = $stmt->fetch()) {
        echo "<tr>
            <td>" . $row["nid"] . "</td>
            <td>" . $row["ntitle"] . "</td>
            <td>" . $row["cn"] . "</td>
            <td>" . ($row["ns"] == "show" ? "مفعل" : "معطل") . "</td>
            <td>" . $row["nin"] . "</td>
            <td>" . $row["nsr"] . "</td>
            <td>
                <a class='btn btn-primary' href='news-manage.php?action=enable&id=" . $row["nid"] . "'>تفعيل</a>
                <a class='btn btn-danger' href='news-manage.php?action=disable&id=" . $row["nid"] . "'>تعطيل</a>
                <a class='btn btn-warning' href='news-add.php?id=" . $row["nid"] . "'>تعديل</a>
            </td>
        </tr>";
    }
} catch (PDOException $e) {
    echo "خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage();
}

?>


        </table>

    </div>
</div>
