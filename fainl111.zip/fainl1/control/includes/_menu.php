<nav class="navbar navbar-expand-lg navbar-light  mt-3 mb-3 hideonprint shadow" style="background-color: hsl(50, 53%, 91%);" >

  <div class="container-fluid">
    <a class="navbar-brand" href="#"> </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <div class="control me-2">
    <a class="btn btn-outline-warning" href="index.php">العودة</a>
</div>
    
      </ul>
         <div>
         &nbsp; &nbsp; <a href='logout.php' class='btn btn-outline-warning'>تسجيل الخروج</a>&nbsp; &nbsp; <a href='profile.php' class='btn btn-outline-warning'>حسابي</a>    </div>
    </div>
  </div>
</nav>