<?php
    include("includes/_data.php");
    session_start();
    if(isset($_SESSION["un"])==false && isset($_SESSION["phone"])==false)
    {
     
    header("location:login.php");
        
    }
    
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="" />
    <meta name="keywords" content=" تصاميم" />
    <meta name="author" content="Abubaker" />
    <title>تصاميم</title>
   <?php include("includes/_css.php"); ?>
</head>
<body class="p-4 text-dark bg-opacity-50">
<div class="container bg-light mt-1 rounded ">

<div class="row">
    <div class="col-12 text-center mt-3 hideonprint">
    <img width="350px" src="../imges/logo.png" alt="..."/>
    </div>
    <?php include("includes/_menu.php"); ?>
