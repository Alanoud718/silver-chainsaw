    <!-- Css - Start -->
    <link href="../css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link href="../css/style.css" rel="stylesheet" />
    <!-- Css - End -->