<?php
//error reporting
// error_reporting(0);

//db config


   //error reporting
   //error reporting(0);


   // db config
    $n="localhost";
    $usern="root";
    $userp="";
    $b="disigins";
    
    $con = new mysqli($n,$usern,$userp,$b);

    mysqli_set_charset($con,'utf8');



$un="root";
$up="";
$db="disigins";
$sn="localhost";

try {
    $conn = new PDO("mysql:host=$sn;dbname=$db", $un, $up);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch(PDOException $e) {
    echo "فشل الاتصال: " . $e->getMessage();
}
?>