<?php require_once("includes/_header.php"); ?>
<style>
    .msgtr{
        cursor:pointer;
    }
    .unread{
    font-weight: bolder;
    }
    .read{
    font-weight: lighter;
    }
</style>
    
    <div class="h1  p-3 test-end">رسائل الزوار</div>
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
            <table class="table table-hover table-bordered">
    <tr class="bg-primary text-light">
        <th>وقت الإرسال</th>
        <th>مرسل الرسالة</th>
        <th>عنوان الرسالة</th>
    </tr>
    <?php

try {
    $stmt = $conn->prepare("SELECT * FROM msg ORDER BY mid DESC");
    $stmt->execute();

    while ($row = $stmt->fetch()) {
        echo "<tr class='msgtr" . ($row["ms"] == "unread" ? " unread" : "") . "' onClick='viewMail(" . $row["mid"] . ")'>";
        echo "<td>" . $row["min"] . "</td>";
        echo "<td>" . $row["mname"] . "</td>";
        echo "<td>" . $row["msubject"] . "</td>";
        echo "</tr>";
    }
} catch (PDOException $e) {
    echo "خطأ في جلب الرسائل من قاعدة البيانات: " . $e->getMessage();
}

?>

        </table>
         </div>
        </div>
    </div>
<script>
    function viewMail(id)
    {
        window.location.href="msg-view.php?mid="+id;
    }
</script>

   
  <?php require_once("includes/_footer.php"); ?>