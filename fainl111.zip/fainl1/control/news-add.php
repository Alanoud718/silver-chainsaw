<?php
    include "includes/_header.php";

    $title="";

    $btn="";

    if(isset($_GET["id"]))
    {
        $title="تعديل تصميم";
        $btn="تعديل";
        $nid=$_GET["id"];
        //جلب البيانات القديمة حتى يتاح تعديلها

        $siglat = $con->query("SELECT * FROM news WHERE nid=$nid");
        $sigle = $siglat->fetch_assoc();
        $nt = $sigle["ntitle"];
        $ne = $sigle["nexert"];
        $nlt = $sigle["ntext"];
        $na = $sigle["nauthor"];
        $ns = $sigle["nsource"];
        $ni = $sigle["nimg"];
        $nx = $sigle["cid"];
        
    }
    else
    {
        $title="إضافة تصميم";
        $btn="حفظ";
    }
    

    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
        //تحديد نوع الطلب،هل هو حفظ لجديد او تعديل لقديم
        if(isset($_POST["btn_add"]))
        {
            //حفظ
            if($_FILES["uimg"]["size"]>0)
            {
                //توليد الرقم الفريد العشوائي الخاص بالتصميم
                $npid=date("Ymd")."-".time();

                //news vars
                $nt=$_POST["ut"];
                $ne=$_POST["ue"];
                $nlt=$_POST["ult"];
                $cid=$_POST["uc"];
                $na=$_POST["ua"];
                $ns=$_POST["us"];    

                //تجهيز إسم الصورة التي تم إختيارها
                $fn="uploads/news-".date("Ymd")."-".time().".jpg";

                move_uploaded_file($_FILES["uimg"]["tmp_name"],$fn);
                
                $con->query("INSERT INTO news (npid,cid,ntitle,nexert,ntext,nsource,nauthor,nimg) VALUES ('$npid',$cid,'$nt','$ne','$nlt','$ns','$na','$fn')");
                $msg = "تم إضافة التصميم بنجاح";
            }
            else
            {
                $msg="يجب تحديد الصورة المرافقة للتصميم";
            }
        }
        else
        {
            //تعديل

            //news vars
            $nt=$_POST["ut"];
            $ne=$_POST["ue"];
            $nlt=$_POST["ult"];
            $cid=$_POST["uc"];
            $na=$_POST["ua"];
            $ns=$_POST["us"]; 
            $nid=$_POST["nid"]; 

            //توليد الرقم الفريد العشوائي الخاص بالتصميم
            $npid=date("Ymd")."-".time();


            if($_FILES["uimg"]["size"]>0)
            {
                //تجهيز إسم الصورة التي تم إختيارها
                $fn="uploads/news-".date("Ymd")."-".time().".jpg";

                move_uploaded_file($_FILES["uimg"]["tmp_name"],$fn);
                
                $con->query("UPDATE news SET npid='$npid', cid=$cid, ntitle='$nt', nexert='$ne', ntext='$nlt', nsource='$ns', nauthor='$na', nimg='$fn' WHERE nid=$nid");
                $msg = "تم تعديل التصميم بنجاح";
            }
            else
            {
                $con->query("UPDATE news SET npid='$npid', cid=$cid, ntitle='$nt', nexert='$ne', ntext='$nlt', nsource='$ns', nauthor='$na' WHERE nid=$nid");
                $msg = "تم تعديل التصميم بنجاح";
            }
        }
    }
?>
    <style>
        form>div{margin:10px 0;}
    </style>
    <div class="row">
        <div class="col-12">
            <div class="h3"><?php echo $title; ?><a href='news-manage.php' class='btn btn-outline-warning float-start'>إدارة التصاميم</a></div>
            <?php
               if(isset($msg) && strlen($msg)>0)
               {
                   echo "<div class='alert alert-success mt-5 mb-5 p-3'>$msg</div>";
               }
            ?>
            <div>
                <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST" enctype="multipart/form-data">
                   <input id="nid" name="nid" value="<?php if(isset($_GET["id"])){echo $_GET["id"];} ?>"  type="hidden" />
                   <div>
                       <label class="form-label" for="uc">القسم</label>
                       <select class="form-select" id="uc" name="uc">
                         <?php
                              $records = $con->query("SELECT * FROM cats WHERE cs='active';");
                              while($record = $records->fetch_assoc())
                              {
                                 echo '<option value="'.$record["cid"].'" '.($record["cid"]==$nx?"selected":"").' >'.$record["cn"].'</option>';
                              }
                           ?>
                       </select>
                   </div>
                   <div>
                       <label class="form-label" for="ut">عنوان التصميم</label>
                       <input class="form-control" type="text" id="ut" name="ut" oninput="mohamed();" value="<?php if(isset($nt)){echo $nt;} ?>" required="required" maxlength="99" />
                          <div id="mo">
                              <div id="ww"><span>0</span>/100</div>
                          </div>
                   </div> 
                   <div>
                       <label class="form-label" for="ue">ملخص عن التصميم</label>
                       <input class="form-control" type="text" id="ue" name="ue" value="<?php if(isset($ne)){echo $ne;} ?>" required="required" maxlength="198" />
                   </div>
                   <div>
                       <label class="form-label" for="ult">التصميم</label>
                       <textarea rows="15" class="form-control" id="ult" name="ult" required="required"><?php if(isset($nlt)){echo $nlt;} ?></textarea>
                   </div> 
                   <div>
                       <label class="form-label" for="us">البرامج المستخدمة في التصميم</label>
                       <input class="form-control" type="text" id="us" name="us" value="<?php if(isset($ns)){echo $ns;} ?>" maxlength="50" />
                   </div>
                   <div>
                       <label class="form-label" for="ua">المصمم</label>
                       <input class="form-control" type="text" id="ua" name="ua" value="<?php if(isset($na)){echo $na;} ?>" maxlength="50" />
                   </div>
                   <div>
                       <label class="form-label" for="uimg">صورة من التصميم</label>
                       <?php
                          if(isset($ni))
                          {
                             echo "<div class='mb-3'><img class='img-thumbnail w-50' src='$ni' alt='' /></div>";
                             echo "<div class='small mb-3'>قم برفع صورة جديدة فقط في حال رغبت بتغيير الصورة الظاهرة</div>";
                          }
                       ?>
                       <input class="form-control" type="file" accept="image/jpeg" id="uimg" name="uimg" <?php if($btn=="حفظ"){echo 'required="required"';} ?>  />
                   </div>
                   <div class="text-start">
                       <?php
                           if($btn=="حفظ")
                           {
                              echo '<button type="submit" class="btn btn-primary" id="btn_add" name="btn_add"> حفظ </button>';
                           }
                           else
                           {
                              echo '<button type="submit" class="btn btn-primary" id="btn_edit" name="btn_edit"> تعديل </button>';
                           }
                       ?>
                   </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        function mohamed()
        {
            var x=document.getElementById("ut").value.length;
            var z=document.getElementById("ut").value;
            document.getElementById("ww").innerHTML= x  + "/100";
            if(z.length >= 90)
            {
               document.getElementById("mo").style.color="red";
            }
            else
            {
               document.getElementById("mo").style.color="green";
            }
            
        }
    </script>