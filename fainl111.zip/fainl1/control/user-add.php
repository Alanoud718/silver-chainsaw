<?php

require_once ("includes/_header.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if ($_FILES["uimg"]["size"] > 0) {

        if ($_FILES["uimg"]["type"] == "image/jpeg") {

            $filename = "uploads/" . "user-" . date("Ymd") . "-" . time() . ".jpg";
            move_uploaded_file($_FILES["uimg"]["tmp_name"], $filename);

            $udn = $_POST["udn"];
            $un = $_POST["un"];
            $up = $_POST["up"];
            $ut = $_POST["ut"];
            $hashed_password = password_hash($_POST['up'], PASSWORD_BCRYPT);
            try {
                $stmt = $conn->prepare("INSERT INTO users(udn, un, up, ut, us, uimg) VALUES (:udn, :un, :up , :ut, 'active', :filename)");
                $stmt->bindParam(":udn", $udn);
                $stmt->bindParam(":un", $un);
                $stmt->bindParam(":up", $hashed_password);
                $stmt->bindParam(":ut", $ut);
                $stmt->bindParam(":filename", $filename);
                $stmt->execute();

                echo "<div class='alert alert-success mt-3 mb-3'>تم اضافة مستخدم</div>";
            } catch (PDOException $e) {
                echo "خطأ في إضافة المستخدم: " . $e->getMessage();
            }
        } else {
            echo "Invalid File type";
        }
    } else {
        echo "Error, No file";
    }
}

?>

    <div class="h1  p-3 text-end"> ادارة المستخدمين <a href='user-manage.php' class='btn btn-outline-warning float-start'>إدارة المستخدمين</a></div>
    <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">
    <div>
                <label class="form-label" for="udn">الإسم</label>
                <input class="form-control" type="text" id="udn" name="udn" placeholder="أدخل الإسم" required="required" maxlength="50"/>
            </div>
            <div>
                <label class="form-label" for="un">الهاتف</label>
                <input class="form-control" type="phone" id="un" name="un" placeholder="أدخل رقم الجوال" required="required" maxlength="9"/>
            </div>
            <div>
                <label class="form-label" for="up">كلمة السر</label>
                <input class="form-control" type="password" id="up" name="up" placeholder="أدخل كلمة السر" required="required" maxlength="9"/>
            </div>

            <div>
                <label class="form-label" for="ut">نوع الحساب</label>
                <select class="form-select" name="ut" id="ut" >
                    <option value="admin">مدير النظام</option>
                    <option value="editor">مصمم</option>
                    <option value="author">مصور</option>
                    <option value="publisher">منتج</option>
                </select>
            </div>
            <div class="mt-3">
            <label class="form-label" for="uimg">الصورة</label>
            <input class="form-control" type="file" id="uimg" name="uimg" required="required" maxlength="255"/>
            </div>
<div class="text-start mt-3">
    <button id="btn" type="submit " class="btn btn-primary"> حفظ إضافة مستخدم</button>
</div>
   </form>
    </div>
    </div>
</div>





<script>
       $('#btn').on('click', function (){
           $wal.fire({
               type: 'success',
               title: 'your title !',
               text: 'your text'
           })
       })
   </script>

<?php require_once("includes/_footer.php"); ?>