<?php require_once("includes/_header.php");

    //statustucs
 
    // 3. قم بتنفيذ الاستعلام
$records = $conn->query("SELECT COUNT(*) as 'nc' FROM news;");

// 4. احصل على السجلات من الاستعلام
$record = $records->fetch();

    
// 5. قم بتعيين القيمة إلى المتغير
$nc = $record["nc"];

// 6. قم بطباعة القيمة

?>
           <div class="container">
            <div class="row">
                <div class='col-4'>
                    <nav id='sidebarMenu' >
        <div class='col-xl-2 col-lg-3 col-md-4 sidebar position-absolute border-left' id='pagetitle'>
            <div class='sidebar-header'>
            <div class='nav-item'>
                <a class='nav-link text-white' href='#'>
                    <span class='home'></span>
                    <i class='fa fa-home mr-2' aria-hidden='true'></i> لوحة التحكم  </a>
            </div>
            </div>   
            <ul class='nav flex-column'>
            <li class='nav-item px-2'>
                <a class='nav-link' href='msg-manage.php'>
                <span data-feather='file'></span>
                <i class='fa fa-commenting-o' aria-hidden='true'></i>&nbsp;&nbsp;  إدارة الرسائل </a>
            </li>
            <li class='nav-item px-2'>
                <a class='nav-link' href='cat-add.php'>
                <span data-feather='file'></span>
                <i class='fa fa-money' aria-hidden='true'></i>&nbsp;&nbsp;  إضافة قسم </a>
            </li>
            <li class='nav-item px-2'>
                <a class='nav-link' href='cat-manage.php'>
                <span data-feather='users'></span>
                <i class='fa fa-book mr-2' aria-hidden='true'></i>&nbsp;&nbsp; إدارة الأقسام </a>
            </li>
            <li class='nav-item  px-2'>
                <a class='nav-link ' href='slider-add.php'>
                <span data-feather='file'></span>
                <i class='fa fa-archive' aria-hidden='true'></i>&nbsp;&nbsp;  إضافة سليدر </a>
            </li>
            <li class='nav-item px-2'>
                <a class='nav-link' href='slider-manage.php'>
                <span data-feather='file'></span>
                <i class='fa fa-file-archive-o' aria-hidden='true'></i> &nbsp;&nbsp;   إدارة السليدر </a>
            </li>
            <li class='nav-item  px-2'>
                <a class='nav-link' href='news-add.php'>
                <span data-feather='layers'></span>
                <i class='fa fa-bar-chart mr-2' aria-hidden='true'></i>&nbsp;&nbsp; إضافة تصميم </a>
            </li>
            <li class='nav-item  px-2'>
                <a class='nav-link' href='news-manage.php'>
                <span data-feather='layers'></span>
                <i class='fa fa-bar-chart mr-2' aria-hidden='true'></i>&nbsp;&nbsp; إدارة التصاميم </a>
            </li>
            <li class='nav-item  px-2'>
                <a class='nav-link' href='user-man.php'>
                <span data-feather='layers'></span>
                <i class='fa fa-bar-chart mr-2' aria-hidden='true'></i>&nbsp;&nbsp;   حسابات الزوار </a>
            </li>
            <li class='nav-item px-2'>
                <a class='nav-link' href='user-manage.php'>
                <span data-feather='file'></span>
                <i class='fa fa-book mr-2' aria-hidden='true'></i>&nbsp;&nbsp; حسابات الادمن </a>
            </li>
            <li class='nav-item  p2-2'>
                <a class='nav-link' href='user-add.php'>
                <span data-feather='layers'></span>
                <i class='fa fa-bar-chart mr-2' aria-hidden='true'></i>&nbsp;&nbsp;   اضافة ادمن </a>
            </li>
            </ul>  
            </div>     
        </nav>
                </div>
                <div class='card col-lg-8 p-4'>
                <div class='m-2'>
                        <div class='card-body m-1'>
                            <h5 class='card-title text-center'>الأخبار</h5>
                            <!-- <p class='card-text text-center'><?php echo $nc; ?></p> -->
                            <a href='news-manage.php' class='btn btn-outline-warning w-100'>إدارة الأخبار</a>
                        </div>
                    </div>
                    <p style="text-align: justify;">ما المقصود بالموقع؟
        موقع الويب هو عبارة عن مجموعة من الصفحات على الويب ذات صلة تتم استضافتها بواسطة خادم HTTP على شبكة الإنترنت العالمية أو موقع إنترانت. تمتلك معظم مواقع الويب صفحة رئيسية تعتبر هي نقطة بدايتها. يتم ربط هذه الصفحة الرئيسية بشكل متداخل مع الصفحات الأخرى باستخدام الارتباطات التشعبية. يمكنك استخدام مواقع المستوى الأعلى على الويب ومواقع الويب الفرعية لتقسيم محتوى الموقع إلى مواقع مميزة يمكن إدارتها بشكل منفصل. من الممكن أن تتضمن مواقع المستوى الأعلى على الويب عدة مواقع ويب فرعية والتي بدورها قد تتضمن بداخلها مواقع ويب فرعية متعددة. تسمى البنية الكاملة لموقع المستوى الأعلى على الويب وكل مواقعه الفرعية بـ مجموعة المواقع المشتركة على الويب.
        يتيح هذا التدرج الهرمي للمستخدمين إمكانية الحصول على موقع عمل رئيسي للفريق بأكمله فضلاً عن مواقع عمل منفردة أو مواقع مشتركة للمشاريع الأخرى. تسمح مواقع المستوى الأعلى على الويب ومواقع الويب الفرعية بمستويات التحكم المختلفة على ميزات المواقع وإعداداتها. يتحكم مسؤول موقع الويب في القدرة على إنشاء محتوى والوصول إليه والمساهمة به في موقع ويب.
        أعلى الصفحة
        ما المقصود بمساحة العمل؟
        مساحة العمل هي موقع ويب فريد يتم إنشاؤه وتوفير أدوات التعاون والخدمات من خلاله لأعضاء الفريق من أجل التعاون في العمل على المستندات أو الحصول على الموارد المتعلقة بالاجتماعات. من الممكن أن تتضمن مساحة العمل قوائم معلومات مثل المستندات ذات الصلة وأعضاء الفريق والارتباطات. لإنشاء موقع مساحة عمل، يجب أن تكون عضواً في أحد مستويات الأذونات وتملك الإذن لإنشاء مواقع ويب فرعية لموقع SharePoint هذا. تتيح لك Windows SharePoint Services إمكانية إنشاء مواقع مساحات العمل
        <br/>
        <br/>
        <br>
        <br><br>
        </p>
            </div>
            </div>  
            </div>
            
      <?php require_once("includes/_footer.php"); ?>
      