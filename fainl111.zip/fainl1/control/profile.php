<?php

require_once "includes/_header.php";

try {
    $stmt = $conn->prepare("SELECT * FROM users WHERE uid=:uid");
    $stmt->bindParam(":uid", $_SESSION["uid"]);
    $stmt->execute();

    $row = $stmt->fetch();

    $uid = $row["uid"];
    $un = $row["udn"];
    $up = $row["un"];

    if ($row["ut"] == "admin") {
        $ut = "مدير النظام";
    } else if ($row["ut"] == "editor") {
        $ut = "مصمم";
    } else if ($row["ut"] == "author") {
        $ut = "مصور";
    } else {
        $ut = "منتج";
    }

    $us = ($row["us"] == "active" ? "مفعل" : "معطل");
    $ul = $row["ulin"];
} catch (PDOException $e) {
    echo "خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage();
}

?>

<style>
    form>div{margin:10px 0};
</style>
<div class="row">
    <div class="col-6">
        <div class="h3">بيانات حسابي</div>
                <div>
                    <label class="form-label" for="uid">الرقم</label>
                    <input class="form-control" value="<?php echo $uid; ?>" type="text" readonly="true" />
                </div>
                <div>
                    <label class="form-label" for="un">الاسم</label>
                    <input class="form-control" value="<?php echo $un; ?>" type="text" readonly="true" />
                </div>
                <div>
                    <label class="form-label" for="up">الهاتف</label>
                    <input class="form-control" value="<?php echo $up; ?>" type="phone" readonly="true" />
                </div>
                <div>
                    <label class="form-label" for="ut">نوع الحساب</label>
                    <input class="form-control" value="<?php echo $ut; ?>" type="text" readonly="true"/>
                </div>
                <div>
                    <label class="form-label" for="us">حالة الحساب</label>
                    <input class="form-control" value="<?php echo $us; ?>" type="text" readonly="true"/>
                    </div>
                <div>
                    <label class="form-label" for="ul">أخر ظهور</label>
                    <input class="form-control" value="<?php echo $ul; ?>" type="text" readonly="true"/>
                </div>
    </div>
    <div class="col-6">
    <div class="h3">تغيير كلمة السر</div>
    <?php

require_once "includes/_header.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $up1=$_POST["up1"];
        if (strlen($_POST["up2"]) >= 5) {
            if ($_POST["up2"] == $_POST["up3"]) {

            
                $hashed_password2 = password_hash($_POST["up2"], PASSWORD_BCRYPT);

                $stmt = $conn->prepare("SELECT up FROM users WHERE uid=:uid");
                $stmt->bindParam(":uid", $_SESSION["uid"]);
                $stmt->execute();
                $row = $stmt->fetch();

                if (password_verify($up1, $row["up"])) {

                    $stmt = $conn->prepare("UPDATE users SET up=:up WHERE uid=:uid");
                    $stmt->bindParam(":up", $hashed_password2);
                    $stmt->bindParam(":uid", $_SESSION["uid"]);
                    $stmt->execute();

                    echo "<div class='alert alert-success'>تم تغيير كلمة السر بنجاح</div>";
                } else {
                    echo "<div class='alert alert-danger'>كلمة السر القديمة غير صحيحة</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>كلمة السر الجديدة غير متطابقة</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>كلمة السر الجديدة قصيرة</div>";
        }
   
}



?>
   
    <div >
        <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="POST">
            <div>
                <label class="form-label" for="up1">كلمة السر الحالية</label>
                <input class="form-control" type="password" id="up1" name="up1"  required="required" />
            </div>
            <div>
                <label class="form-label" for="up2">كلمة السر الجديدة</label>
                <input class="form-control" type="password" id="up2" name="up2"  required="required" />
            </div>
            <div>
                <label class="form-label" for="up3">تأكيد السر الجديدة</label>
                <input class="form-control" type="password" id="up3" name="up3"  required="required" />
            </div>
            
<div class="text-start">
    <button type="submit " class="btn btn-primary"> تغيير كلمة المرور</button> &nbsp;&nbsp;
    <a href="logout.php"  class="btn btn-danger">تسجيل الخروج</a>
</div>
        </form>
    </div>

    </div>


</div>
