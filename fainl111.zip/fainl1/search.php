<?php require_onc("includes/_header.php");
    if(isset($_GET["st"])==false)
    {
        header("location:index.php");
        exit();
    }

    $searchTerm=$_GET["st"];
    ?>
    <style>
        mark{background-color:darkred;color:white;border-radius:5px;}
    </style>
    <!-- News Cards - Start -->
    <div class="row mt-5">
    <?php
// PDO connection (assuming you've already established it)

$stmt = $conn->prepare("SELECT * FROM news WHERE ns='show' and (ntitle LIKE ? OR ntext LIKE ?) ORDER BY nid desc");
$stmt->bindParam(1, $searchTerm);
$stmt->bindParam(2, $searchTerm);
$stmt->execute();

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $title = $row["ntitle"];
    $exert = $row["nexert"];

    if (strlen($title) > 80) {
        $title = substr($title, 0, 80);
        $title = substr($title, 0, strrpos($title, " ")) . " ... ";
        $title = str_replace($searchTerm, "<mark>$searchTerm</mark>", $title);  // Highlight search terms
    }

    if (strlen($exert) > 180) {
        $exert = substr($exert, 0, 180);
        $exert = substr($exert, 0, strrpos($exert, " ")) . " ... ";
    }

    echo '<div class="card col-lg-3">
        <a href="news-view.php?id=' . $row["nid"] . '"><img src="control/' . $row["nimg"] . '" class="card-img-top" alt="..."></a>
        <div class="card-body">
            <h5 class="card-title"><a href="news-view.php?id=' . $row["nid"] . '">' . $title . '</a></h5>
            <p class="card-text text-justify"><a href="news-view.php?id=' . $row["nid"] . '">' . $exert . '</a></p>
            <a href="news-view.php?id=' . $row["nid"] . '" class="btn btn-primary w-100">تفاصيل الخبر</a>
        </div>
    </div>';
}
?>

      </div>
   <!-- News Cards - End -->

    <?php require_onc("includes/_footer.php"); ?>