   <?php require("includes/_header.php");?>
   <div><a href="index.php"><i class="fa fa-reply-all text-warning" aria-hidden="true"></i>الصفحة الرئيسية</a> </div>
   <?php
// PDO connection

if (!isset($_GET["id"])) {
    header("location:index.php");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM news WHERE nid=:nid");
$stmt->bindParam(':nid', $_GET["id"]);
$stmt->execute();

if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $title = $row["ntitle"];
    $img = "control/" . $row["nimg"];
    $exert = $row["nexert"];
    $text = $row["ntext"];
    $in = $row["nin"];
    $source = $row["nsource"];
    $author = $row["nauthor"];

    // Update views
    $stmt = $conn->prepare("UPDATE news SET nsr=nsr+1 WHERE nid=:nid");
    $stmt->bindParam(':nid', $_GET["id"]);
    $stmt->execute();
} else {
    // Handle the case where no news item is found
    // (e.g., redirect or display an error message)
}
?>
    <div class="h3 text-center p-3"><?php echo $title;  ?></div>
    <div class="row">
        <div class="col-6">
           <img class='img-fluid rounded' src='<?php echo $img; ?>' alt='<?php echo $title;  ?>' />
        </div>
        <div class="col-6">
            <div style='text-align: justify;' class='fs-3 text-primary bg-light p-3'><?php echo $exert; ?></div>        
            <div class='text-center'><?php echo $in; ?></div>
            <?php if(strlen($author)>0){ echo '<div  class="p-3">الكاتب : '.$author.' </div>';}?>
            <div style='text-align: justify;' class='p-3 fs-5 '><?php echo $text; ?></div>
            <?php if(strlen($source)>0){ echo '<div  class="p-3">المصدر : '.$source.' </div>';}?>
        </div>
    </div>
<div>
          <!-- news Card - start -->
      <div class="row mt-3">
      <?php
// PDO connection (assuming you've already established it)

$stmt1 = $conn->prepare("SELECT * FROM news WHERE ns='show' and nid <> :nid ORDER BY rand() LIMIT 4");
$stmt1->bindParam(':nid', $_GET["id"]);
$stmt1->execute();

while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
    $title = $row["ntitle"];
    $exert = $row["nexert"];

    if (strlen($title) > 80) {
        $title = substr($title, 0, 80);
        $title = substr($title, 0, strrpos($title, " ")) . " ... ";
    }
    if (strlen($exert) > 180) {
        $exert = substr($exert, 0, 180);
        $exert = substr($exert, 0, strrpos($exert, " ")) . " ... ";
    }

    echo '<div class="card col-lg-3">
        <a href="news-view.php?id=' . $row["nid"] . '"><img src="control/' . $row["nimg"] . '" class="card-img-top border border-bordered" alt="..."/></a>
        <div class="card-body">
            <h5 class="card-title"><a href="news-view.php?id=' . $row["nid"] . '">' . $title . '</a></h5>
            <p class="card-text "><a href="news-view.php?id=' . $row["nid"] . '">' . $exert . '</a></p>
            <a href="news-view.php?id=' . $row["nid"] . '" class="btn btn-primary w-100">تفاصيل أكثر</a>
        </div>
    </div>';
}
?>

      </div>
     <!-- news Card - end -->
</div>

</div>


    <?php require_onc("includes/_footer.php"); ?>