
   <?php require_once("includes/_header.php");
   
   $sql = "SELECT * FROM cats WHERE cid=:cid";
   $stmt = $conn->prepare($sql);
   $stmt->bindParam(":cid", $_GET["cid"]);
   $stmt->execute();
   
   // استخراج الصف
   $row = $stmt->fetch();
   
   // تعيين قيمة اسم 
   $cat = $row["cn"];

   ?>
        <div class="h3 text-center p-3"><?php echo $cat; ?></div>
        <div class="row mt-3">
        <?php

// استعلام PDO
$sql = "SELECT * FROM news WHERE ns='show' and cid=:cid ORDER BY nid DESC";
$stmt = $conn->prepare($sql);
$stmt->bindParam(":cid", $_GET["cid"]);
$stmt->execute();

// جلب النتائج وطباعة بطاقات التصميم
while ($row = $stmt->fetch()) {
   $title = $row["ntitle"];
   $exert = $row["nexert"];

   // تقصير العنوان والملخص
   if (strlen($title) > 80) {
       $title = substr($title, 0, 80) . " ... ";
   }
   if (strlen($exert) > 180) {
       $exert = substr($exert, 0, 180) . " ... ";
   }

   echo '<div class="card col-lg-3">
       <a href="news-view.php?id=' . $row["nid"] . '"><img src="control/' . $row["nimg"] . '" class="card-img-top border border-bordered" alt="..."/></a>
       <div class="card-body">
           <h5 class="card-title"><a href="news-view.php?id=' . $row["nid"] . '">' . $title . '</a></h5>
           <p class="card-text "><a href="news-view.php?id=' . $row["nid"] . '">' . $exert . '</a></p>
           <a href="news-view.php?id=' . $row["nid"] . '" class="btn btn-dark-warning w-100">تفاصيل التصميم</a>
       </div>
   </div>';
}
?>
      </div>
    </div>

    <?php require_once("includes/_footer.php"); ?>